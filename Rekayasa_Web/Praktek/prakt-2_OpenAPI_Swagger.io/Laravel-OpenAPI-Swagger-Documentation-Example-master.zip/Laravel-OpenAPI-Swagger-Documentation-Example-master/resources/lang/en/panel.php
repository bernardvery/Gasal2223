<?php

return [
    'site_title' => 'OpenAPI Demo',
];
